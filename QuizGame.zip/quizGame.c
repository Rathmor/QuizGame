#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <time.h>

int getNumberOfLinesInFile(char *filename) {
    FILE *file;
    char c;
    int noOfLines = 1;
    if ((file = fopen(filename, "r")) == NULL) {
        printf("File not found!");
        return -1;
    }
    c = getc(file);
    while (c != EOF) {
        if (c == '\n') {
            noOfLines ++;
        }
        c = getc(file);
    }
    return noOfLines;
}

void loadQnA(char *filename, char **questions, char **answers, int noOfLines) {
    FILE *file;
    file = fopen(filename, "r");
    char c;
    char line[255];
    char *question;
    char *answer;
    for (int i=0; i<noOfLines; i++) {
        fgets(line, 255, file);
        question = strtok(line, "_");
        answer = strtok(NULL, "\n");
        questions[i] = (char *)malloc(sizeof(char) *(strlen(question)));
        answers[i] = (char *)malloc(sizeof(char) *(strlen(answer)));
        strcpy(questions[i], question);
        strcpy(answers[i], answer);
    }
}

void showFirstAndLast(char *answer, char *blankAnswer) {
    blankAnswer[0] = answer[0];
    blankAnswer[strlen(blankAnswer)-1] = answer[strlen(answer)-1];
}

void showTwoRandom(char *answer, char *blankAnswer) {
    int count = 0;
    for (int i=0; i<strlen(blankAnswer); i++) {
        if (blankAnswer[i] != '-') {
            count++;
        }
    }
    if (count == strlen(blankAnswer)) {
        return;
    }

    int randomIndex1 = (rand() % ((strlen(answer)-2) - 1 + 1)) + 1;
    while (blankAnswer[randomIndex1] != '-') {
        randomIndex1 = (rand() % ((strlen(answer)-2) - 1 + 1)) + 1;
    }
    blankAnswer[randomIndex1] = answer[randomIndex1];
    count = 0;
    for (int i=0; i<strlen(blankAnswer); i++) {
        if (blankAnswer[i] != '-') {
            count++;
        }
    }
    if (count == strlen(blankAnswer)) {
        return;
    }

    int randomIndex2 = (rand() % ((strlen(answer)-2) - 1 + 1)) + 1;
    while (blankAnswer[randomIndex2] != '-') {
        randomIndex2 = (rand() % ((strlen(answer)-2) - 1 + 1)) + 1;
    }
    blankAnswer[randomIndex2] = answer[randomIndex2];
}

int startQuizGame(char **questions, char **answers, int noOfQuestions, int difficultyLevel) {
    srand(time(NULL));
    int i = 0;
    int questionsRead = 0;
    int score = 0;
    int guesses;
    int randomIndex;
    char choice;
    char questionsWrong[noOfQuestions-1];
    char questionsRemaining[noOfQuestions-1];
    for (int o=0; o<noOfQuestions; o++) {
        questionsRemaining[o] = '-';
        questionsWrong[o] = '-';
    }
    if (difficultyLevel < 5) {
        while (questionsRead < noOfQuestions) {
            guesses = 0;
            randomIndex = (rand() % ((noOfQuestions-1) - 0 + 1)) + 0;
            while (questionsRemaining[randomIndex] == '0') {
                randomIndex = (rand() % ((noOfQuestions-1) - 0 + 1)) + 0;
            }
            questionsRemaining[randomIndex] = '0';
            char answer[strlen(answers[randomIndex])];
            answer[strlen(answers[randomIndex])] = '\0';
            char blankAnswer[strlen(answers[randomIndex])-1];
            char guess[strlen(answers[randomIndex])];

            for (int o=0; o<strlen(answers[randomIndex]); o++) {
                answer[o] = toupper(answers[randomIndex][o]);
                blankAnswer[o] = '-';
            }

            blankAnswer[strlen(answer)] = '\0';
            printf("%s\n", questions[randomIndex]);
            printf("?\n");
            printf("::");

            scanf("%s", guess);
            for (int o=0; o<strlen(guess); o++) {
                guess[o] = toupper(guess[o]);
            }

            while (strcmp(guess, answer) != 0) {
                if (guesses == 5) {
                    questionsWrong[randomIndex] = '0';
                    break;
                } else if (guesses == 1) {
                    showFirstAndLast(answer, blankAnswer);
                } else if (guesses > 1) {
                    showTwoRandom(answer, blankAnswer);
                }
                fflush(stdin);
                printf("Nope, try again!\n");
                printf("%s\n", questions[randomIndex]);
                for (int o=0; blankAnswer[o] != '\0'; o++) {
                    if (o == strlen(blankAnswer)-1) {
                        printf("%c\n", blankAnswer[o]);
                        break;
                    }
                    printf("%c ", blankAnswer[o]);
                }
                guesses++;
                printf("::");
                scanf("%s", guess);
                for (int o=0; o<strlen(guess); o++) {
                    guess[o] = toupper(guess[o]);
                }
            }
            if (strcmp(guess, answer) == 0) {
                score++;
                printf("\n%d/%d\n", score, noOfQuestions);
            } else {
                printf("\n%d/%d\n", score, noOfQuestions);
            }
        questionsRead++;
        }
        fflush(stdin);
        printf("\n\nWould you like to see the answers for the questions you guessed incorrectly? (y/n):");
        scanf("%c", &choice);
        choice = tolower(choice);
        if (choice == 'y') {
            for (int i=0; i<strlen(questionsWrong); i++) {
                if (questionsWrong[i] == '0') {
                    printf("\n%s\nCorrect Answer: %s", questions[i], answers[i]);
                }
            }
        }
        return score;
    }
    if (difficultyLevel == 5) {
        int randomAnswerIndex;
        int count;
        while (questionsRead < noOfQuestions) {
            guesses = 0;
            count = 0;
            randomIndex = (rand() % ((noOfQuestions-1) - 0 + 1)) + 0;
            while (questionsRemaining[randomIndex] == '0') {
                randomIndex = (rand() % ((noOfQuestions-1) - 0 + 1)) + 0;
            }
            questionsRemaining[randomIndex] = '0';
            char answer[strlen(answers[randomIndex])];
            answer[strlen(answers[randomIndex])] = '\0';
            char guess[strlen(answers[randomIndex])];

            for (int o=0; o<strlen(answers[randomIndex]); o++) {
                answer[o] = toupper(answers[randomIndex][o]);
            }

            char answerCopy[strlen(answer)];
            for (int o=0; o<strlen(answer); o++) {
                answerCopy[o] = answer[o];
            }

            printf("%s\n", questions[randomIndex]);
            while (count < strlen(answer)) {
                randomAnswerIndex = (rand() % ((strlen(answer)-1) - 0 + 1)) + 0;
                while (answerCopy[randomAnswerIndex] == '0') {
                    randomAnswerIndex = (rand() % ((strlen(answer)-1) - 0 + 1)) + 0;
                }
                printf("%c ", answer[randomAnswerIndex]);
                answerCopy[randomAnswerIndex] = '0';
                count++;
            }

            printf("\n::");
            scanf("%s", guess);
            for (int o=0; o<strlen(guess); o++) {
                guess[o] = toupper(guess[o]);
            }

            while (strcmp(guess, answer) != 0) {
                if (guesses == 5) {
                    questionsWrong[randomIndex] = '0';
                    break;
                }
                fflush(stdin);
                printf("Nope, try again!\n");
                printf("%s\n", questions[randomIndex]);
                for (int o=0; o<strlen(answer); o++) {
                    answerCopy[o] = answer[o];
                }
                count = 0;
                while (count < strlen(answer)) {
                    randomAnswerIndex = (rand() % ((strlen(answer)-1) - 0 + 1)) + 0;
                    while (answerCopy[randomAnswerIndex] == '0') {
                        randomAnswerIndex = (rand() % ((strlen(answer)-1) - 0 + 1)) + 0;
                    }
                    printf("%c ", answer[randomAnswerIndex]);
                    answerCopy[randomAnswerIndex] = '0';
                    count++;
                }
                guesses++;
                printf("\n::");
                scanf("%s", guess);
                for (int o=0; o<strlen(guess); o++) {
                    guess[o] = toupper(guess[o]);
                }
            }
            if (strcmp(guess, answer) == 0) {
                score++;
                printf("\n%d/%d\n", score, noOfQuestions);
            } else {
                printf("\n%d/%d\n", score, noOfQuestions);
            }
        questionsRead++;
        }
        fflush(stdin);
        printf("\n\nWould you like to see the answers for the questions you guessed incorrectly? (y/n):");
        scanf("%c", &choice);
        choice = tolower(choice);
        if (choice == 'y') {
            for (int i=0; i<strlen(questionsWrong); i++) {
                if (questionsWrong[i] == '0') {
                    printf("\n%s\nCorrect Answer: %s", questions[i], answers[i]);
                }
            }
        }
        return score;
    }
    if (difficultyLevel == 6) {
        int randomclue;
        while (questionsRead < noOfQuestions) {
            guesses = 0;
            randomIndex = (rand() % ((noOfQuestions-1) - 0 + 1)) + 0;
            while (questionsRemaining[randomIndex] == '0') {
                randomIndex = (rand() % ((noOfQuestions-1) - 0 + 1)) + 0;
            }
            questionsRemaining[randomIndex] = '0';
            char answer[strlen(answers[randomIndex])];
            answer[strlen(answers[randomIndex])] = '\0';
            char blankAnswer[strlen(answers[randomIndex])-1];
            char guess[strlen(answers[randomIndex])];

            for (int o=0; o<strlen(answers[randomIndex]); o++) {
                answer[o] = toupper(answers[randomIndex][o]);
                blankAnswer[o] = '-';
            }

            blankAnswer[strlen(answer)] = '\0';
            printf("%s\n", questions[randomIndex]);
            printf("?\n");
            printf("::");

            scanf("%s", guess);
            for (int o=0; o<strlen(guess); o++) {
                guess[o] = toupper(guess[o]);
            }

            while (strcmp(guess, answer) != 0) {
                if (guesses == 5) {
                    questionsWrong[randomIndex] = '0';
                    break;
                }
                randomclue = (rand() % (3 - 0 + 1)) + 0;
                fflush(stdin);
                printf("Nope, try again!\n");
                printf("%s\n", questions[randomIndex]);
                if (randomclue == 0) {
                    printf("?\n");
                } else if (randomclue == 1) {
                    for (int i=0; i<strlen(answer); i++) {
                        if (i == strlen(answer)-1) {
                            printf("-\n");
                        } else {
                            printf("- ");
                        }
                    }
                } else if (randomclue == 2) {
                    showFirstAndLast(answer, blankAnswer);
                    for (int o=0; blankAnswer[o] != '\0'; o++) {
                        if (o == strlen(blankAnswer)-1) {
                            printf("%c\n", blankAnswer[o]);
                            break;
                        }
                    printf("%c ", blankAnswer[o]);
                    }
                } else if (randomclue == 3) {
                    showTwoRandom(answer, blankAnswer);
                    for (int o=0; blankAnswer[o] != '\0'; o++) {
                        if (o == strlen(blankAnswer)-1) {
                            printf("%c\n", blankAnswer[o]);
                            break;
                        }
                    printf("%c ", blankAnswer[o]);
                    }
                }
                guesses++;
                printf("::");
                scanf("%s", guess);
                for (int o=0; o<strlen(guess); o++) {
                    guess[o] = toupper(guess[o]);
                }
            }
            if (strcmp(guess, answer) == 0) {
                score++;
                printf("\n%d/%d\n", score, noOfQuestions);
            } else {
                printf("\n%d/%d\n", score, noOfQuestions);
            }
        questionsRead++;
        }
        fflush(stdin);
        printf("\n\nWould you like to see the answers for the questions you guessed incorrectly? (y/n):");
        scanf("%c", &choice);
        choice = tolower(choice);
        if (choice == 'y') {
            for (int i=0; i<strlen(questionsWrong); i++) {
                if (questionsWrong[i] == '0') {
                    printf("\n%s\nCorrect Answer: %s", questions[i], answers[i]);
                }
            }
        }
        return score;
    }
    if (difficultyLevel > 6) {
        while (questionsRead < noOfQuestions) {
            guesses = 0;
            randomIndex = (rand() % ((noOfQuestions-1) - 0 + 1)) + 0;
            while (questionsRemaining[randomIndex] == '0') {
                randomIndex = (rand() % ((noOfQuestions-1) - 0 + 1)) + 0;
            }
            questionsRemaining[randomIndex] = '0';
            char answer[strlen(answers[randomIndex])];
            answer[strlen(answers[randomIndex])] = '\0';
            char guess[strlen(answers[randomIndex])];

            for (int o=0; o<strlen(answers[randomIndex]); o++) {
                answer[o] = toupper(answers[randomIndex][o]);
            }

            printf("%s\n", questions[randomIndex]);
            printf("?\n");
            printf("::");

            scanf("%s", guess);
            for (int o=0; o<strlen(guess); o++) {
                guess[o] = toupper(guess[o]);
            }

            while (strcmp(guess, answer) != 0) {
                if (guesses == 5) {
                    questionsWrong[randomIndex] = '0';
                    break;
                }
                fflush(stdin);
                printf("Nope, try again!\n");
                printf("%s\n", questions[randomIndex]);
                printf("?\n");
                guesses++;
                printf("::");
                scanf("%s", guess);
                for (int o=0; o<strlen(guess); o++) {
                    guess[o] = toupper(guess[o]);
                }
            }
            if (strcmp(guess, answer) == 0) {
                score++;
                printf("\n%d/%d\n", score, noOfQuestions);
            } else {
                printf("\n%d/%d\n", score, noOfQuestions);
            }
        questionsRead++;
        }
        fflush(stdin);
        printf("\n\nWould you like to see the answers for the questions you guessed incorrectly? (y/n):");
        scanf("%c", &choice);
        choice = tolower(choice);
        if (choice == 'y') {
            for (int i=0; i<strlen(questionsWrong); i++) {
                if (questionsWrong[i] == '0') {
                    printf("\n%s\nCorrect Answer: %s", questions[i], answers[i]);
                }
            }
        }
        return score;
    }
}

void main (void) {
    FILE *File;
    char filename[8];
    int difficulty;
    printf("Enter name of file:");
    scanf("%s", filename);
    int noOfLines = getNumberOfLinesInFile(filename);
    if (noOfLines == -1) {
        exit(0);
    }
    char *questions[noOfLines];
    char *answers[noOfLines];
    loadQnA(filename, questions, answers , noOfLines);
    printf("[There are %d questions in this file]\n", noOfLines);
    while (true) {
        printf("\nEnter difficulty (<10):");
        scanf("%d", &difficulty);
        if (difficulty > 10 || difficulty < 0) {
            printf("Difficulty must be between 0 and 10!");
            fflush(stdin);
        } else {
            break;
        }
    }
    int score = startQuizGame(questions, answers, noOfLines, difficulty);
    File = fopen ("quiz_history.txt","w");
    fprintf(File, "%s,  -  %d answered correctly  -  %d questions  -  %d difficulty", filename, score, noOfLines, difficulty);
}
